package CommonScreen;

public class CartScreen {
	public static final String CHECKOUT_BTN_XPATH 			= "//button[@class='button btn-checkout']";
	
}
